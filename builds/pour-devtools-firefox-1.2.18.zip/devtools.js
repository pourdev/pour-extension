(()=>{chrome.devtools.panels.create("pour DevTools","","panel.html");})();
