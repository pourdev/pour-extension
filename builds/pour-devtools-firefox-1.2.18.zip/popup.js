(()=>{var ie={wcagVersion:"2.2",level:"AA",bestPractices:!1,hoverScroll:!0},le=[{group:"Rules",fields:[{key:"wcagVersion",label:"WCAG",type:"select",options:["2.0","2.1","2.2",{value:"3.0-draft",label:"3.0 (draft)"}]},{key:"level",label:"Level",type:"select",options:["A","AA","AAA"]},{key:"bestPractices",label:"Best practices",type:"checkbox"}]},{group:"Display",fields:[{key:"hoverScroll",label:"Scroll to element on hover",type:"checkbox"}]}],N="auditSettings";async function q(){let e=await chrome.storage.sync.get(N);return{...ie,...e[N]}}async function ce(e){await chrome.storage.sync.set({[N]:e})}function ue(e){chrome.storage.onChanged.addListener((t,a)=>{a==="sync"&&t[N]&&e({...ie,...t[N].newValue})})}var re=new Set(["wcag2a","wcag2aa","wcag2aaa","wcag21a","wcag21aa","wcag22aa"]);function de(e){if(e.wcagVersion==="3.0-draft"){let s=[...re];return e.bestPractices&&s.push("best-practice"),{tags:s,standard:"wcag30-draft"}}let t={"2.0":["2"],"2.1":["2","21"],"2.2":["2","21","22"]}[e.wcagVersion],a={A:["a"],AA:["a","aa"],AAA:["a","aa","aaa"]}[e.level],n=t.flatMap(s=>a.map(i=>`wcag${s}${i}`)).filter(s=>re.has(s));return e.bestPractices&&n.push("best-practice"),{tags:n}}var U=e=>`audit:${e}`;async function pe(e){return(await chrome.storage.session.get(U(e)))[U(e)]??null}function ge(e,t){chrome.storage.onChanged.addListener((a,n)=>{n==="session"&&a[U(e)]&&t(a[U(e)].newValue??null)})}var Be=/establish connection|receiving end|message manager disconnected/i;async function A(e){let t=150;for(let a=0;;a++)try{return await chrome.runtime.sendMessage(e)}catch(n){if(a>=2||!Be.test(String(n?.message??n)))throw n;await new Promise(s=>setTimeout(s,t)),t*=3}}async function he(e){let t=de(await q());return A({type:"run-audit-in-tab",tabId:e,options:t})}function me(e,t,a){return A({type:"set-filter-in-tab",tabId:e,kind:t,mode:a})}function j(e){return A({type:"set-filter-in-tab",tabId:e,kind:"clear"})}function z(e){return A({type:"get-filter-state-in-tab",tabId:e})}function fe(e){return A({type:"cancel-audit-in-tab",tabId:e})}async function be(e,t){return A({type:"show-element-in-tab",tabId:e,target:t})}function K(e){return A({type:"diagnose-tab",tabId:e})}function ye(e){return A({type:"reload-tab",tabId:e})}function ve(e,t,a=!0){return A({type:"hover-element-in-tab",tabId:e,target:t,scroll:a})}var H="2026-08-03 21:19:42";var qe=/establish connection|receiving end|message manager disconnected|no response from (the )?page|no response from the extension/i,V=e=>qe.test(String(e?.message??e??"")),Ue=["chrome:","chrome-untrusted:","edge:","about:","moz-extension:","chrome-extension:","devtools:","view-source:","chrome-error:","resource:"],je=["chromewebstore.google.com","chrome.google.com/webstore","addons.mozilla.org"];function G(e){let t=e?.tab?.url??e?.topFrame?.url??null,a=t?`${t.split(":")[0]}:`:null;return e?.topFrame?.ok?{headline:"pour can reach this page now",cause:"pour is loaded in the page, so whatever blocked the last run has cleared.",steps:["Run the audit again."],canReload:!1}:!e?.tab&&e?.tabError?{headline:"That tab is gone",cause:"The tab was closed or replaced before the audit could reach it.",steps:["Open the page again and re-run the audit."],canReload:!1}:a&&Ue.includes(a)?{headline:"The browser blocks extensions on this page",cause:`Browser-internal pages (${a}) are off limits to every extension, pour included.`,steps:["Open the page you want to audit in a normal tab."],canReload:!1}:t&&je.some(n=>t.includes(n))?{headline:"The browser blocks extensions on this site",cause:"Browsers forbid extensions from running on their own add-on stores.",steps:["Audit the page on its own site instead."],canReload:!1}:a==="file:"?{headline:"File access is switched off",cause:"Local files need an explicit permission that is off by default, so pour can\u2019t see this one.",steps:["Open chrome://extensions, find pour, and turn on \u201CAllow access to file URLs\u201D.","Then reload the file and run the audit again."],canReload:!0}:{headline:"pour isn\u2019t running on this page",cause:"The audit runs inside the page, and the browser hasn\u2019t loaded pour there. In order of likelihood:",steps:["The tab was already open when pour was installed or updated \u2014 the browser only loads it into pages opened after that. Reload the page.","Your organisation\u2019s browser policy blocks extensions on this domain (common for internal apps). Check chrome://policy for ExtensionSettings \u2192 runtime_blocked_hosts.","Site access is set to \u201COn click\u201D or \u201COn specific sites\u201D. Check chrome://extensions \u2192 pour \u2192 Site access \u2192 \u201COn all sites\u201D.","The tab is showing a certificate warning, a login wall or an error page rather than the app itself. Get to the real page first, then run the audit."],canReload:!0}}function we(e){let t=s=>s?"yes":"no",a=[`${e.product??"pour"} diagnostic report`,`when: ${e.at}`,`extension: v${e.version} (${e.browser}), built ${e.build}`,`engine: v${e.engineVersion}`,`surface: ${e.scope??"unknown"}`,`browser: ${e.userAgent??"unknown"}`,"",`failing action: ${e.action??"run audit"}`,`error: ${e.error??"(none recorded)"}`,"",`tab id: ${e.tabId}`,`tab url: ${e.tab?.url??"(not visible to the extension \u2014 please paste the page URL here)"}`,`tab status: ${e.tab?.status??"unknown"}${e.tab?.discarded?" (discarded)":""}`,`top frame reachable: ${t(e.topFrame?.ok)}${e.topFrame?.ok?"":` \u2014 ${e.topFrame?.error??"no reply"}`}`,`any frame reachable: ${t(e.anyFrame?.ok)}`,e.topFrame?.ok?`page engine: ${e.topFrame.engine} (readyState ${e.topFrame.readyState})`:null,`granted origins: ${e.granted?.origins?.length?e.granted.origins.join(", "):"(none listed)"}`,`granted permissions: ${e.granted?.permissions?.join(", ")??"(unknown)"}`].filter(Boolean),n=G(e);if(a.push("",`likely cause: ${n.headline}`,n.cause),n.steps.forEach((s,i)=>a.push(`  ${i+1}. ${s}`)),e.failures?.length){a.push("",`recent failures this session (${e.failures.length}):`);for(let s of e.failures)a.push(`  ${s.at} \xB7 tab ${s.tabId} \xB7 ${s.error}`)}return e.settings&&a.push("",`settings: ${JSON.stringify(e.settings)}`),a.push("","What were you doing when this happened?","  "),a.join(`
`)}function $e(e,{scope:t,error:a,action:n,settings:s,product:i,engineVersion:m,version:r,browser:g}){return{...e,scope:t,action:n,error:String(a?.message??a??""),settings:s,product:i,engineVersion:m,version:e?.version??r,browser:e?.browser??g,build:e?.build??H,userAgent:navigator.userAgent,at:e?.at??new Date().toISOString()}}var He={protanopia:"0.152286 1.052583 -0.204868 0 0 0.114503 0.786281 0.099216 0 0 -0.003882 -0.048116 1.051998 0 0 0 0 0 1 0",deuteranopia:"0.367322 0.860646 -0.227968 0 0 0.280085 0.672501 0.047414 0 0 -0.011820 0.042940 0.968881 0 0 0 0 0 1 0",tritanopia:"1.255528 -0.076749 -0.178779 0 0 -0.078411 0.930809 0.147602 0 0 0.004733 0.691367 0.303900 0 0 0 0 0 1 0",achromatopsia:"0.212656 0.715158 0.072186 0 0 0.212656 0.715158 0.072186 0 0 0.212656 0.715158 0.072186 0 0 0 0 0 1 0",protanomaly:"0.458064 0.679578 -0.137642 0 0 0.092785 0.846313 0.060902 0 0 -0.007494 -0.016807 1.024301 0 0 0 0 0 1 0",deuteranomaly:"0.547494 0.607765 -0.155259 0 0 0.181692 0.781742 0.036566 0 0 -0.010410 0.027275 0.983136 0 0 0 0 0 1 0",tritanomaly:"1.057047 -0.029507 -0.027540 0 0 -0.039014 0.966028 0.072986 0 0 0.002584 0.220200 0.777216 0 0 0 0 0 1 0"},Ve={protanopia:"saturate(0.25) sepia(0.5) hue-rotate(-15deg)",deuteranopia:"saturate(0.3) sepia(0.4) hue-rotate(-10deg)",tritanopia:"saturate(0.35) sepia(0.3) hue-rotate(50deg)",achromatopsia:"grayscale(100%)",protanomaly:"saturate(0.6) sepia(0.25) hue-rotate(-8deg)",deuteranomaly:"saturate(0.65) sepia(0.2) hue-rotate(-5deg)",tritanomaly:"saturate(0.7) sepia(0.15) hue-rotate(25deg)"};var xe={none:"none",cataract:"sepia(0.3) contrast(0.9) saturate(0.9) brightness(0.95) blur(0.6px)",presbyopia:"blur(0.5px) contrast(0.92)",lowAcuityMild:"blur(0.7px)",lowAcuity:"blur(1.2px)",lowAcuityStrong:"blur(2.5px)",lowAcuityHeavy:"blur(5px)",lowLight:"brightness(0.65) contrast(0.9) saturate(0.85) hue-rotate(-8deg)",lowContrast:"contrast(0.7)",glaucoma:"none",glaucomaLarge:"none",macularDegeneration:"none",macularDegenerationLarge:"none",diabeticRetinopathy:"none",nystagmus:"none",hemianopiaLeft:"none",hemianopiaRight:"none",amblyopia:"none",scotopicRose:"sepia(0.15) hue-rotate(330deg) saturate(1.2) brightness(1.05)",scotopicYellow:"sepia(0.3) saturate(1.15) brightness(1.05)",scotopicAqua:"sepia(0.2) hue-rotate(160deg) saturate(1.15) brightness(1.02)"},Ge=typeof navigator<"u"&&/^((?!chrome|android).)*safari/i.test(navigator.userAgent),Ye=typeof navigator<"u"&&/firefox/i.test(navigator.userAgent),We=Ge||Ye;Object.keys(He).forEach(e=>{We?xe[e]=Ve[e]:xe[e]=`url(#pour-vision-filter-${e})`});var X=[{label:"Color vision",options:[{value:"deuteranomaly",label:"Green Weak - Deuteranomaly - ~5%"},{value:"protanomaly",label:"Red Weak - Protanomaly - ~1%"},{value:"protanopia",label:"Red Absent - Protanopia - ~1%"},{value:"deuteranopia",label:"Green Absent - Deuteranopia - ~1%"},{value:"tritanomaly",label:"Blue Weak - Tritanomaly - <0.1%"},{value:"tritanopia",label:"Blue Absent - Tritanopia - <0.1%"},{value:"achromatopsia",label:"Monochromacy - Achromatopsia - ~0.003%"}]},{label:"Eye conditions",options:[{value:"presbyopia",label:"Near-Vision Loss - Presbyopia - ~100% over 40"},{value:"glaucoma",label:"Tunnel Vision - Glaucoma - ~2% over 40"},{value:"glaucomaLarge",label:"Tunnel Vision (Large) - Advanced Glaucoma - ~0.5% over 40"},{value:"macularDegeneration",label:"Central Vision Loss - Macular Degeneration - ~8% over 45"},{value:"macularDegenerationLarge",label:"Central Vision Loss (Large) - Advanced Macular Degeneration - ~1.5% over 45"},{value:"diabeticRetinopathy",label:"Patchy Vision - Diabetic Retinopathy - ~3%"},{value:"nystagmus",label:"Involuntary Eye Movement - Nystagmus - ~0.2%"}]},{label:"Field of vision",options:[{value:"hemianopiaLeft",label:"Left Field Loss - Hemianopia (Left) - ~0.8%"},{value:"hemianopiaRight",label:"Right Field Loss - Hemianopia (Right) - ~0.8%"},{value:"amblyopia",label:"Reduced Acuity (One Eye) - Amblyopia - ~2-3%"}]},{label:"Focus & acuity",options:[{value:"lowAcuityMild",label:"Slight Defocus - Mild Blur - ~25%"},{value:"lowAcuity",label:"Uncorrected Focus - Moderate Blur - ~12%"},{value:"lowAcuityStrong",label:"Significant Defocus - Strong Blur - ~5%"},{value:"lowAcuityHeavy",label:"Severe Defocus - Very Strong Blur - ~1%"}]},{label:"Contrast & light",options:[{value:"cataract",label:"Clouded Lens - Cataract - ~17% over 40"},{value:"lowContrast",label:"Reduced Contrast"},{value:"lowLight",label:"Dim Environment - Low Light"}]},{label:"Visual stress",options:[{value:"scotopicRose",label:"Rose Tint - Coloured Overlay"},{value:"scotopicYellow",label:"Yellow Tint - Coloured Overlay"},{value:"scotopicAqua",label:"Aqua Tint - Coloured Overlay"}]}];var J=[{label:"Sensory overload",options:[{value:"fluorescentFlicker",label:"Fluorescent Flicker"},{value:"lightSensitivity",label:"Light Sensitivity"},{value:"colourHypersensitivity",label:"Colour Hypersensitivity"},{value:"motionSensitivity",label:"Motion Sensitivity"}]},{label:"Attention & focus",options:[{value:"hyperfocusTunnel",label:"Hyperfocus Tunnel (Metaphor)"},{value:"attentionFragmentation",label:"Attention Fragmentation (Metaphor)"},{value:"peripheralDistraction",label:"Peripheral Distraction"},{value:"detailFixation",label:"Detail Fixation (Metaphor)"}]},{label:"Processing differences",options:[{value:"processingDelay",label:"Processing Lag"},{value:"sensoryInterference",label:"Sensory Interference"}]},{label:"Sensory spikes",options:[{value:"sensorySpike",label:"Sudden Sensory Spike"}]},{label:"Dyslexia / reading",options:[{value:"dyslexiaVisualStress",label:"Visual Stress (Pattern Glare)"},{value:"dyslexiaCrowding",label:"Crowding Effect"},{value:"dyslexiaTrackingLoss",label:"Tracking Loss"},{value:"dyslexiaWashout",label:"Letter Instability"},{value:"dyslexiaContrastSensitivity",label:"Contrast Sensitivity"}]}],Z={};for(let e of[...X,...J])for(let t of e.options)Z[t.value]=t.label.split(" - ")[0];var Q=2*Math.PI*42;function ee({impacts:e,counts:t,totalElements:a,hidden:n}){let s=e.filter(g=>t[g].elements);if(!s.length||!a)return"";let i=s.length>1?2:0,m=0;return`
    <svg class="impact-donut" viewBox="0 0 120 120" width="104" height="104" aria-hidden="true">
      <g transform="rotate(-90 60 60)">${s.map(g=>{let h=t[g].elements/a,v=Math.max(h*Q-i,1.5),$=`
      <circle class="donut-seg seg-${g}${n.has(g)?" off":""}"
              cx="60" cy="60" r="42" fill="none" stroke-width="14"
              stroke-dasharray="${v.toFixed(2)} ${(Q-v).toFixed(2)}"
              stroke-dashoffset="${(-m-i/2).toFixed(2)}">
        <title>${g} \u2014 ${t[g].elements} element${t[g].elements===1?"":"s"} (${Math.round(h*100)}%)</title>
      </circle>`;return m+=h*Q,$}).join("")}</g>
      <text class="donut-total" x="60" y="58">${a}</text>
      <text class="donut-caption" x="60" y="78">element${a===1?"":"s"}</text>
    </svg>`}var O=["critical","serious","moderate","minor","review"],M=O.filter(e=>e!=="review"),l=e=>String(e??"").replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]),Y=(e,t)=>`${e} ${t}${e===1?"":"s"}`;function ze(e){if(!e.data?.foreground||!e.data?.background)return"";let t=n=>encodeURIComponent(n.replace(/\s+/g,"")),a=`https://contrast-ratio.org/#${t(e.data.foreground)}-on-${t(e.data.background)}`;return`<br /><a href="${l(a)}" target="_blank" rel="noreferrer">Try this pair on contrast-ratio.org</a>`}function Ce(e){let t=O.map(n=>`${e.issues.filter(s=>s.impact===n).length} ${n}`).join(" \xB7 ")+` (elements) \u2014 ${new Set(e.issues.map(n=>n.ruleId)).size} issue types`,a=[`Audit \u2014 ${e.url} at ${new Date(e.timestamp).toLocaleString()}`,`${e.engine}${e.durationMs!=null?` \u2014 ${e.durationMs}ms`:""} \xB7 ${e.rulesChecked??"?"} rules checked`,t,""];return e.standard?.draft&&a.splice(2,0,`${e.standard.name} ${e.standard.status} (${e.standard.dated}) \u2014 ${e.standard.note}`),e.issues.forEach((n,s)=>{a.push(`${s+1}. [${n.impact}] ${n.ruleId}${n.principles?.length?` (${n.principles.join("/")})`:""} \u2014 ${n.target}`),a.push(`   ${n.failureSummary.replace(/\n/g,`
   `)}`),a.push(`   ${n.helpUrl}`)}),e.issues.length||a.push("No violations found."),a.join(`
`)}function Te(e,t,a){e.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(t()),e.textContent="Copied \u2713"}catch(n){a?.(n),e.textContent="Copy failed"}setTimeout(()=>{e.textContent="Copy results"},2e3)})}function Se(e){switch(e.type){case"select":return`<label>${l(e.label)}
        <select data-key="${e.key}">
          ${e.options.map(t=>`<option value="${l(t.value??t)}">${l(t.label??t)}</option>`).join("")}
        </select></label>`;case"number":return`<label>${l(e.label)} <input type="number" min="0" data-key="${e.key}" /></label>`;default:return`<label><input type="checkbox" data-key="${e.key}" /> ${l(e.label)}</label>`}}function Ke(){return[["vision","Vision",X],["sensory","Sensory & cognitive",J]].map(([e,t,a])=>`
    <h2 class="filter-section">${l(t)}</h2>
    ${a.map(n=>`
      <div class="filter-group">${l(n.label)}</div>
      ${n.options.map(s=>{let i=s.label.split(" - ");return`
        <button type="button" class="filter-option" data-kind="${e}" data-value="${l(s.value)}" aria-pressed="false">
          <span class="option-name">${l(i[0])}</span>
          ${i.length>1?`<span class="option-meta">${l(i.slice(1).join(" \xB7 "))}</span>`:""}
        </button>`}).join("")}`).join("")}`).join("")}function Ae(){let[e,...t]=le;return`
    <div class="seg-control" role="tablist" aria-label="Mode">
      <button type="button" class="seg" id="seg-audit" role="tab" aria-selected="true" aria-controls="panel-audit" data-tab="audit">A11y Audit</button>
      <button type="button" class="seg" id="seg-filters" role="tab" aria-selected="false" aria-controls="filters-panel" tabindex="-1" data-tab="filters">Vision Modes</button>
    </div>
    <div id="panel-audit" role="tabpanel" aria-labelledby="seg-audit">
    <form id="options">
      <div class="options-row">
        ${e.fields.map(Se).join("")}
      </div>
      <button id="run-audit" type="button">
        <span class="run-main">
          <!-- Lucide: play -->
          <svg class="icon-play" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><polygon points="6 3 20 12 6 21 6 3"/></svg>
          <!-- Lucide: square -->
          <svg class="icon-stop" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>
          <span class="run-label">Run audit</span>
        </span>
      </button>
      ${t.length?`
        <details class="advanced">
          <summary>Advanced settings</summary>
          ${t.map(a=>`
            <fieldset>
              <legend>${l(a.group)}</legend>
              ${a.fields.map(Se).join("")}
            </fieldset>`).join("")}
        </details>`:""}
    </form>
    <div id="status" aria-live="polite"></div>
    <div id="trouble" hidden></div>
    <div id="summary"></div>
    <div id="issues"></div>
    </div>
    <div id="filters-panel" role="tabpanel" aria-labelledby="seg-filters">
      <div class="filters-head">
        <p class="filters-note">Experience this page the way others see it. Audits pause while a mode is active.</p>
        <button id="clear-filters" type="button" disabled>Clear</button>
      </div>
      <p id="filters-status" aria-live="polite"></p>
      ${Ke()}
    </div>
    <p id="version">v1.2.18 \xB7 pour engine v1.1.8 \xB7 built ${H}</p>`}function _e(e,{onChange:t}={}){let a=e.querySelector(".seg-control"),n=[...a.querySelectorAll(".seg")],s=(i,m=!1)=>{e.dataset.tab=i.dataset.tab;for(let r of n){let g=r===i;r.setAttribute("aria-selected",String(g)),r.tabIndex=g?0:-1}m&&i.focus(),t?.(i.dataset.tab)};for(let i of n)i.addEventListener("click",()=>s(i));a.addEventListener("keydown",i=>{let m={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1}[i.key],r=null;if(m){let g=n.indexOf(a.getRootNode().activeElement);r=n[(g+m+n.length)%n.length]}else i.key==="Home"?r=n[0]:i.key==="End"&&(r=n[n.length-1]);r&&(i.preventDefault(),s(r,!0))})}function Le({headline:e,cause:t,steps:a=[],canReload:n=!1}){return`
    <div class="troubleshoot" role="group" aria-label="Audit could not reach the page">
      <p class="trouble-head">${l(e)}</p>
      <p class="trouble-cause">${l(t)}</p>
      ${a.length?`<ol class="trouble-steps">${a.map(s=>`<li>${l(s)}</li>`).join("")}</ol>`:""}
      <div class="trouble-actions">
        ${n?'<button id="trouble-reload" type="button" class="primary">Reload page &amp; retry</button>':""}
        <button id="trouble-report" type="button">Report a bug</button>
      </div>
      <div id="trouble-report-out" hidden>
        <p class="trouble-cause">Copy this and email it to <strong id="trouble-address"></strong>. It says which of the causes above actually applies. Nothing leaves this window unless you send it.</p>
        <textarea id="trouble-report-text" rows="10" readonly aria-label="Diagnostic report"></textarea>
        <div class="trouble-actions">
          <button id="trouble-copy" type="button">Copy report</button>
        </div>
      </div>
    </div>`}function Ee(){return`
    <div class="empty-state">
      <svg viewBox="0 0 32 32" width="26" height="26" aria-hidden="true" focusable="false">
        <rect x="2" y="2" width="10.5" height="10.5"></rect>
        <rect x="19.5" y="2" width="10.5" height="10.5"></rect>
        <rect x="2" y="19.5" width="10.5" height="10.5"></rect>
        <rect x="19.5" y="19.5" width="10.5" height="10.5"></rect>
      </svg>
      <p><strong>No audit yet for this tab</strong>
      <span>Run an audit to check this page against WCAG,
      or open Vision Modes to experience it the way others see it.</span></p>
    </div>`}function P(e,{running:t,hasResults:a=!1}){e.classList.toggle("running",t),e.querySelector(".run-label").textContent=t?"Stop audit":a?"Re-run audit":"Run audit"}function te(e,t){for(let a of e){let n=t[a.dataset.key];a.type==="checkbox"?a.checked=!!n:a.value=n}}function Re(e){return Object.fromEntries(e.map(t=>[t.dataset.key,t.type==="checkbox"?t.checked:t.type==="number"?Number(t.value):t.value]))}function Ie(e,t,a){let n=()=>{e.style.setProperty("--seg-h",`${t.offsetHeight}px`),e.style.setProperty("--options-h",`${t.offsetHeight+a.offsetHeight}px`)},s=new ResizeObserver(n);return s.observe(a),s.observe(t),n(),n}function Xe(e){let t=Object.fromEntries(O.map(n=>{let s=e.issues.filter(i=>i.impact===n);return[n,{types:new Set(s.map(i=>i.ruleId)).size,elements:s.length}]})),a=M.reduce((n,s)=>({types:n.types+t[s].types,elements:n.elements+t[s].elements}),{types:0,elements:0});return{counts:t,total:a}}var ke=(e,t,a)=>`
  <button type="button" class="impact impact-${e}" data-impact="${e}"
          data-count="${t[e].elements}" aria-pressed="${!a.has(e)}"
          title="${Y(t[e].types,"issue type")} \xB7 ${Y(t[e].elements,"element")} \u2014 click to show/hide">
    <span class="dot"></span>${e}
    <strong>${t[e].types}</strong>
    <span class="pill-count">${t[e].elements}</span>
  </button>`;function Me(e,{hiddenImpacts:t,extraMeta:a=""}){let{counts:n,total:s}=Xe(e);return`
    <div class="summary-head">
      <p class="result-line">${s.elements?`<strong>${Y(s.types,"issue type")}</strong> \xB7 ${Y(s.elements,"element")} affected`:"<strong>Audit complete</strong>"}</p>
      <button id="copy-audit" type="button">Copy results</button>
    </div>
    <p class="audit-meta">
      <code title="${l(e.url)}">${l(e.url)}</code>
      <span class="meta-facts">${new Date(e.timestamp).toLocaleTimeString()}${e.engine?` \xB7 ${l(e.engine)}`:""}${e.durationMs!=null?` \xB7 ${e.durationMs}ms`:""}${e.rulesChecked!=null?` \xB7 ${e.rulesChecked} rules`:""}</span>
    </p>
    ${e.standard?.draft?`
      <p class="draft-note">
        <strong>${l(e.standard.name)} is a ${l(e.standard.status)} (${l(e.standard.dated)}).</strong>
        ${l(e.standard.note)}
        ${e.standard.url?`<a href="${l(e.standard.url)}" target="_blank" rel="noreferrer">Read the draft</a>.`:""}
      </p>`:""}
    ${a}
    ${s.elements?`
      <div class="summary-viz">
        ${ee({impacts:M,counts:n,totalElements:s.elements,hidden:t})}
        <ul class="impact-summary">
          ${M.map(i=>`<li>${ke(i,n,t)}</li>`).join("")}
        </ul>
      </div>`:`
      <div class="all-clear">
        <!-- Lucide: circle-check-big -->
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/></svg>
        <p><strong>No violations found \u2014 nice work!</strong>
        <span>Every automated check passed on this page.</span></p>
      </div>`}
    ${n.review.elements?`
      <div class="review-strip">
        ${ke("review",n,t)}
        <span class="review-note">Needs human judgement \u2014 not counted as violations.</span>
      </div>`:""}`}function Je(e){let t=Object.fromEntries(O.map((n,s)=>[n,s])),a=new Map;return e.issues.forEach((n,s)=>{let i=`${n.impact}::${n.ruleId}`;a.has(i)||a.set(i,{key:i,impact:n.impact,ruleId:n.ruleId,help:n.help,helpUrl:n.helpUrl,principles:n.principles??[],items:[]}),a.get(i).items.push({issue:n,index:s})}),[...a.values()].sort((n,s)=>t[n.impact]-t[s.impact]||s.items.length-n.items.length||n.ruleId.localeCompare(s.ruleId))}function Ze(e,{withInspect:t=!1}={}){return`
    <summary>
      <span class="group-row">
        <span class="impact impact-${l(e.impact)}">${l(e.impact)}</span>
        <strong class="rule-id">${l(e.ruleId)}</strong>
        <span class="group-count">${e.items.length}</span>
        <span class="group-end">
          ${e.principles.map(a=>`<span class="principle">${l(a)}</span>`).join(" ")}
          <a href="${l(e.helpUrl)}" target="_blank" rel="noreferrer">docs</a>
        </span>
      </span>
      <span class="group-help">${l(e.help)}</span>
    </summary>
    <table>
      <thead><tr><th></th><th>Element</th><th>Why &amp; how to fix</th></tr></thead>
      <tbody>
        ${e.items.map(({issue:a,index:n})=>`
          <tr data-index="${n}">
            <td class="row-actions">
              <button type="button" class="show-element" data-index="${n}">
                <!-- Lucide: eye -->
                <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg>
                Show
              </button>
              ${t?`
              <button type="button" class="inspect-element" data-index="${n}">
                <!-- Lucide: square-mouse-pointer -->
                <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/><path d="m12 12 4 10 1.7-4.3L22 16Z"/></svg>
                Inspect
              </button>`:""}
            </td>
            <td>
              <code>${l(a.target)}</code>
              <pre class="snippet">${l(a.html)}</pre>
            </td>
            <td class="fix">${l(a.failureSummary)}${ze(a)}</td>
          </tr>`).join("")}
      </tbody>
    </table>`}function Oe(e,t,{hiddenImpacts:a,groupToggles:n,withInspect:s=!1}){e.querySelector("#issue-groups")||(e.innerHTML='<div id="issue-notes"></div><div id="issue-groups"></div><div id="issue-extra"></div>');let i=e.querySelector("#issue-notes"),m=e.querySelector("#issue-groups");if(!t.issues.length){i.innerHTML=`<p>No violations found \u2014 ${t.rulesChecked??"?"} rules checked${t.engine?` by ${l(t.engine)}`:""}.</p>`,m.textContent="";return}let g=Je(t).filter(c=>!a.has(c.impact)),h=t.issues.length-g.reduce((c,y)=>c+y.items.length,0);i.innerHTML=h?`<p class="filter-note">${h} issue(s) hidden by severity filter.</p>`:"";let v=e.ownerDocument,$=new Map([...m.querySelectorAll(":scope > details.rule-group")].map(c=>[c.dataset.group,c])),f=null;for(let c of g){let y=$.get(c.key);y||(y=v.createElement("details"),y.className="rule-group",y.dataset.group=c.key,y.open=n.get(c.key)??!1),$.delete(c.key),y.innerHTML=Ze(c,{withInspect:s});let T=f?f.nextSibling:m.firstChild;y!==T&&m.insertBefore(y,T),f=y}for(let c of $.values())c.remove()}var Qe=200;function Fe({summaryEl:e,runButton:t,onMounted:a}){let n=performance.now(),s=null,i=null,m=h=>{let v=M.reduce((f,c)=>f+(h?.[c]??0),0);if(!v)return`
        <svg class="impact-donut" viewBox="0 0 120 120" width="104" height="104" aria-hidden="true">
          <circle class="donut-track" cx="60" cy="60" r="42" fill="none" stroke-width="14"></circle>
          <text class="donut-total" x="60" y="58">0</text>
          <text class="donut-caption" x="60" y="78">elements</text>
        </svg>`;let $=Object.fromEntries(M.map(f=>[f,{elements:h[f]??0}]));return ee({impacts:M,counts:$,totalElements:v,hidden:new Set})},g=setTimeout(()=>{e.innerHTML=`
      <div class="summary-head"><p class="result-line">Auditing\u2026</p></div>
      <div class="summary-viz">
        <div class="live-donut" aria-hidden="true">${m(null)}</div>
        <ul class="impact-summary">
          ${O.map(w=>`
            <li><span class="impact impact-${w}" id="live-${w}" data-count="0">
              <span class="dot"></span>${w}
              <strong>0</strong>
              <span class="pill-count live-elements">0</span>
            </span></li>`).join("")}
        </ul>
      </div>`;let h=w=>e.querySelector(`#${w}`),v=Object.fromEntries(O.map(w=>[w,h(`live-${w}`)])),$=e.querySelector(".live-donut"),f="";a?.(),t.classList.add("has-progress");let c=t.ownerDocument.createElement("span");c.className="run-progress-row",c.innerHTML=`
      <span class="loader-elapsed">0.0</span>s
      <span class="progress indeterminate" role="progressbar" aria-label="Audit progress"
            aria-valuemin="0" aria-valuemax="100"><span class="progress-bar"></span></span>
      <span class="loader-label"></span>`,t.append(c);let y=c.querySelector(".loader-elapsed"),T=c.querySelector(".progress"),_=c.querySelector(".progress-bar"),b=c.querySelector(".loader-label");i=setInterval(()=>{if(y.textContent=((performance.now()-n)/1e3).toFixed(1),s){let w=Math.round(s.done/s.total*100);T.classList.remove("indeterminate"),T.setAttribute("aria-valuenow",w),_.style.width=`${w}%`,b.textContent=`${w}% \xB7 ${s.running?"testing ":""}${s.rule}`;for(let k of O){let L=s.counts?.[k]??0,B=s.typeCounts?.[k]??0;v[k].querySelector("strong").textContent=B,v[k].querySelector(".live-elements").textContent=L,v[k].dataset.count=L}let F=M.map(k=>s.counts?.[k]??0).join(",");F!==f&&(f=F,$.innerHTML=m(s.counts))}},100)},Qe);return{started:n,onProgress(h){!h.counts&&s?.counts&&(h={...h,counts:s.counts,typeCounts:s.typeCounts}),s=h},teardown(){clearTimeout(g),i&&clearInterval(i),t.classList.remove("has-progress"),t.querySelector(".run-progress-row")?.remove()}}}function De(e){let t=`[pour:${e}]`;return{info:(...a)=>console.log(t,...a),warn:(...a)=>console.warn(t,...a),error:(...a)=>console.error(t,...a)}}async function Ne({scope:e,getTabId:t,inspectElement:a}){let n=De(e),s=document.getElementById("app"),i=e==="popup",m='<p class="hint">Open DevTools \u2192 \u201Cpour\u201D tab for the full report.</p>';s.classList.add("audit-app"),s.innerHTML=Ae(),s.dataset.tab="audit";let r=o=>s.querySelector(`#${o}`),g=[...s.querySelectorAll("[data-key]")],h=await q();te(g,h),ue(o=>{h=o,te(g,o)}),r("options").addEventListener("change",()=>ce(Re(g)));let v=Ie(s,s.querySelector(".seg-control"),r("options")),$=[],f=null,c=!1,y=new Set,T=new Map;function _(o){if(o?.engine==="comparison"&&(o=null),o&&f&&o.url!==f.url&&T.clear(),f=o,!o){$=[],P(r("run-audit"),{running:c,hasResults:!1}),r("summary").innerHTML="",r("issues").innerHTML=Ee();return}$=o.issues,P(r("run-audit"),{running:c,hasResults:!0}),r("summary").innerHTML=Me(o,{hiddenImpacts:y}),Te(r("copy-audit"),()=>Ce(o),u=>n.error("clipboard copy failed",u)),i?r("issues").innerHTML=o.issues.length?m:`<p>No violations found \u2014 ${o.rulesChecked??"?"} rules checked.</p>${m}`:Oe(r("issues"),o,{hiddenImpacts:y,groupToggles:T,withInspect:!!a})}let b=await t();n.info(`audit view opened for tab ${b}`),_e(s);let w=[...s.querySelectorAll(".filter-option")],F=r("clear-filters"),k=o=>o.vision!=="none"?o.vision:o.sensory!=="none"?o.sensory:null,L=o=>{if(!o)return;let u=k(o);for(let p of w)p.setAttribute("aria-pressed",String(p.dataset.value===u));F.disabled=!u};z(b).then(o=>L(o?.state)).catch(()=>{});for(let o of w)o.addEventListener("click",async()=>{let p=o.getAttribute("aria-pressed")==="true"?await j(b):await me(b,o.dataset.kind,o.dataset.value);if(!p?.ok){r("filters-status").textContent=`Mode failed: ${p?.error??"no response (try reloading the page)"}`;return}r("filters-status").textContent="",L(p.state)});F.addEventListener("click",async()=>{let o=await j(b);L(o?.ok?o.state:{vision:"none",sensory:"none"})}),_(await pe(b)),ge(b,o=>{n.info("stored audit changed, re-rendering"),_(o)}),r("summary").addEventListener("click",o=>{if(!f)return;let u=o.target.closest(".impact[data-impact]");if(!u)return;let p=u.dataset.impact;y.has(p)?y.delete(p):y.add(p),_(f)}),r("issues").addEventListener("toggle",o=>{let u=o.target.closest?.("details.rule-group");u&&T.set(u.dataset.group,u.open)},!0),r("issues").addEventListener("click",async o=>{let u=o.target.closest(".show-element"),p=o.target.closest(".inspect-element");if(!u&&!p)return;let S=$[Number((u??p).dataset.index)];if(u){n.info("show element",S.target);let C=await be(b,S.target);r("status").textContent=C?.ok?"":`Show failed: ${C?.error??"no response"}`}else{n.info("inspect element",S.target);let C=await a(S.target);r("status").textContent=C?"":"Inspect failed: element not found (the page may have changed since the audit)"}});let B=null,ne=o=>{o!==B&&(B=o,ve(b,o!=null?$[o]?.target??null:null,h.hoverScroll))};r("issues").addEventListener("mouseover",o=>{let u=o.target.closest?.("tr[data-index]");ne(u?Number(u.dataset.index):null)}),r("issues").addEventListener("mouseleave",()=>ne(null));let ae=o=>{r("status").innerHTML=`Auditing will clear the \u201C${l(Z[o]??o)}\u201D mode.
      <button id="confirm-run" type="button">Clear &amp; run</button>`,r("confirm-run").addEventListener("click",async()=>{let u=await j(b).catch(()=>null);L(u?.ok?u.state:{vision:"none",sensory:"none"}),r("status").textContent="",r("run-audit").click()})},x=r("trouble"),se=()=>{x.hidden||(x.hidden=!0,x.innerHTML="",v())};async function Pe(o=15e3){let u=performance.now()+o;for(;performance.now()<u;)if(await new Promise(S=>setTimeout(S,400)),(await K(b).catch(()=>null))?.topFrame?.ok)return!0;return!1}function oe(o,u="run audit"){x.innerHTML=Le(G(null)),x.hidden=!1,v();let p=x.querySelector("#trouble-reload");p?.addEventListener("click",async()=>{if(p.disabled=!0,p.textContent="Reloading\u2026",!(await ye(b).catch(R=>({ok:!1,error:String(R)})))?.ok){p.textContent="Reload failed",p.disabled=!1;return}if(p.textContent="Waiting for the page\u2026",!await Pe()){p.textContent="Still unreachable";return}se(),r("status").textContent="",r("run-audit").click()});let S=x.querySelector("#trouble-report");S.addEventListener("click",async()=>{S.disabled=!0,S.textContent="Checking the page\u2026";let C=await K(b).catch(()=>null),E=$e(C,{scope:e,action:u,error:o,settings:h,product:"pour",engineVersion:"1.1.8",version:"1.2.18",browser:"firefox"});n.error("diagnostic report",E);let R=G(E);x.querySelector(".trouble-head").textContent=R.headline,x.querySelector(".troubleshoot > .trouble-cause").textContent=R.cause,x.querySelector(".trouble-steps").innerHTML=R.steps.map(d=>`<li>${l(d)}</li>`).join("");let D=we(E);x.querySelector("#trouble-report-text").value=D,x.querySelector("#trouble-report-out").hidden=!1,S.hidden=!0,v(),x.querySelector("#trouble-address").textContent="info@pour.dev";let I=x.querySelector("#trouble-copy");I.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(D),I.textContent="Copied \u2713"}catch(d){n.error("clipboard copy failed",d),I.textContent="Copy failed \u2014 select the text above"}setTimeout(()=>{I.textContent="Copy report"},2500)})})}r("run-audit").addEventListener("click",async()=>{let o=r("run-audit");if(c){o.disabled=!0,await fe(b).catch(()=>{});return}let u=await z(b).catch(()=>null),p=u?.state?k(u.state):null;if(p){ae(p);return}c=!0,se(),P(o,{running:!0});let S=Fe({summaryEl:r("summary"),runButton:o,onMounted:()=>{r("issues").classList.add("auditing"),v()}}),C=performance.now(),E=(d,W)=>{d?.type!=="audit-progress"||W.tab?.id!==b||(C=performance.now(),S.onProgress(d))};chrome.runtime.onMessage.addListener(E);let R=3e4,D=null,I=new Promise((d,W)=>{D=setInterval(()=>{performance.now()-C>R&&W(new Error("no response from the extension \u2014 try running again"))},1e3)});I.catch(()=>{});try{n.info(`requesting audit of tab ${b}`);let d=await Promise.race([he(b),I]);r("status").textContent=d?.ok?"":d?.cancelled?"Audit stopped \u2014 previous results kept.":d?.modeActive?"":`Audit failed: ${d?.error??"no response (try reloading the page)"}`,!d?.ok&&!d?.cancelled&&!d?.modeActive&&V(d?.error??"no response")&&(r("status").textContent="Audit failed \u2014 this page could not be reached.",oe(d?.error??"no response from the page")),d?.ok||_(f),d?.modeActive&&ae(d.mode)}catch(d){n.error("audit request failed",d),r("status").textContent=V(d)?"Audit failed \u2014 this page could not be reached.":`Audit failed: ${d?.message??d}`,_(f),V(d)&&oe(d)}finally{S.teardown(),clearInterval(D),chrome.runtime.onMessage.removeListener(E),r("issues").classList.remove("auditing"),c=!1,P(o,{running:!1,hasResults:!!f}),o.disabled=!1}})}Ne({scope:"popup",getTabId:async()=>{let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e.id}});})();
